# Description

This resource is responsible for managing the search file types in the search
service application. You can create new file types, change existing types and
remove existing file types.

The default value for the Ensure parameter is Present. When not specifying this
parameter, the file type is added.
